# Health-Care-Chatbot

<img src="https://www.scnsoft.com/blog-pictures/healthcare/how-chatbots-and-ai-are-changing-the-healthcare-industry_1.png">

    This chatbot will provide quick answers to FAQs by setting up rule-based keyword chatbots 
    with ¨if/then¨ logic. This chatbot will use a series of well-defined rules  to guide 
    customers through a series of menu options that can help answer their questions. 
    It will be there for customers 24/7 on their preferred channels, and simultaneously 
    handle more queries at once. 



<img src="https://miro.medium.com/max/875/1*69vLXZCjrJwdXytj0CTSiQ.jpeg">

PS: Please do not forget to drop a star if you like it!
